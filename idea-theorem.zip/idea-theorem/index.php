<?php //echo get_template_directory_uri(); 
	//bloginfo('template_directory');

?>

<?php get_header(); ?>

<div class="banner">
 
 <div class="banner-box">
	<div class="back-btn">
  <a href="#" ><i class="fa fa-long-arrow-left" aria-hidden="true"></i>BACK TO WORK</a></div>
   <div class="row">
    <div class="col-lg-6 col-md-6 wow fadeInLeft">
    <div class="banner-first">
     <img alt="logo-2" src="<?php echo get_template_directory_uri(); ?>/assets/images/banner-logo.png" width=185>
	 <h2>A Legacy Reinvented</h2>
	  <p class="banner-text">The team at Idea Theorem™ took the time to really understand our business needs and challenges, and ultimately produced a solution which was excellent. Their UX research and design is incredibly thorough and it shows in the final product. We didn’t hesitate beginning another project with them once our first website build was complete.</p>
	  <div class="profile-sec">
	  <div class="row">
	  	<div class="img-sign">
		<div class="img-box ">
			<img alt="Ellipse-1.png" src="<?php echo get_template_directory_uri(); ?>/assets/images/Ellipse.png" width=60>
	  </div>
	  <div class="sing-box" id="sign">
		<h3>Andrew Fuss</h3>
		<p>Senior Marketing Manager</p>
	  </div>
	  </div>
	</div>
	  </div>
    </div>
   
    
  
   <div class="col-lg-6 col-md-6 wow fadeInRight"><div class="ban-img"><span></span></div></div>
  </div><!-- container end here -->
 </div><!-- main-box end here -->
</div><!-- main end here -->
</div>

<section>
	<div class="the-challenge">
		 <div class="row">
			<div class="col-lg-5 col-md-6 last-text">
				<h2>The <span>Challenge</span></h2>
				<p>Established in 1881 as the Ontario Jockey Club, the prestigious Woodbine Entertainment Group is home to Toronto’s only Casino and Race Track for recreational gambling. It also houses a variety of venues for events including restaurants and bars delivering experiences ranging from old-world charm to swanky cosmopolitan vibes. Being the most preferred destination for all kinds of social and private events, Woodbine felt like it needed to revamp their digital presence to consolidate their numer-uno status.</p>
			</div>
			<div class="col-lg-7 col-md-6">
				<div class="challenge-img">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/image-1.png">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/image-2.png">
				</div>
				<div class="challenge-img 2">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/image-3.png">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/image-4.png">
				</div>
			</div>
		</div>	
	</div>
</section>


<?php get_footer(); ?>
