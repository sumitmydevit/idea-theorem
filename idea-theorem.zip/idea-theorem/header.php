<!DOCTYPE html>
<html>
 <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
 
  <title>idea-theorem</title>
  
  <link href="<?php echo get_template_directory_uri(); ?>/assets/css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo get_template_directory_uri(); ?>/style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet">
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <!--load amimate.css from CDN-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css"> 

<!--load WOW js from CDN-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
 </head>
<body>

<header>
 <div class="container-fluid">
  <div class="row">
   <div class="col-lg-3 col-md-5"><img alt="logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" width=200></div>
   
   <div class="col-lg-9 col-md-7">
    <nav class="navbar navbar-expand-md">
     <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
      <span class="sr-only"></span>
      <span class="icon-bar"></span> 
      <span class="icon-bar"></span> 
      <span class="icon-bar"></span>
     </button>
     <div class="navbar-collapse collapse" id="navbarCollapse" style="">
      <div class="mob-logo"><!-- <a href="index.html">LOGO</a> --></div>
      <ul class="navbar-nav"> 
       <li><a class="nav-link" href="#">WORK</a></li>   
       <li><a class="nav-link" href="#">CAPABILITIES <i class="fa fa-chevron-down" aria-hidden="true"></i></a></li>
       <li><a class="nav-link" href="#">INSIGHTS</a></li>
       <li><a class="nav-link nav-contact" href="#">CONTACT</a></li>                  
      </ul><!-- desk-nav end here -->
     </div><!-- navbar-collapse end here -->
    </nav><!-- nav end here -->
   </div><!-- col end here -->
  </div><!-- row end here -->
 </div><!-- container end here -->
</header><!-- header end here -->